class Book{

	//instance variable
	private String author;
	private String title;
	private double price;
	private String publisher;
	private int stock;

    //default constructor
	Book(){
        this.author ="";
        this.title ="";
        this.price = 0.0;
        this.publisher ="";
        this.stock =0;
	}
	//parametrized constructor
	
	Book(String author,String title,double price, String publisher, int stock ){
        this.author = author;
        this.title = title;
        this.price = price;
        this.publisher = publisher;
        this.stock = stock;

    } 


 //to searchbook
 public Boolean searchBook(String title, String author){
 	if((this.title.equals(title))&&(this.author.equals(author))){
 		return true;
 	}
 	return false;
 }
 
 @Override
 public String toString(){
 	return "prize:"+price+ "copies:"+stock;

 }
 public int getCopy(){
 return stock;
 }
 public double getPrice(){
 return price;
 }
 public void update(int stock){
  this.stock-=stock;
 }
}