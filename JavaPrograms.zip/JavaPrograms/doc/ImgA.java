import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;

public class ImgA extends JFrame implements ActionListener
{
  Menu File, Edit, Operations;
  public ImgA()
  {     
    MenuBar mb = new MenuBar();          
    setMenuBar(mb);       
 
 //creating the contents needed on menu bar
    File = new Menu("File");       
    Edit = new Menu("Edit");
    Operations = new Menu("Operations");  
 
    mb.add(File);       
    mb.add(Edit);
    mb.add(Operations);
 

 //options on the Menu bar
    File.addActionListener(this);   
    Edit.addActionListener(this);
    Operations.addActionListener(this);
 
 //adding the options 
    File.add(new MenuItem("New"));
    File.add(new MenuItem("Open"));
    File.add(new MenuItem("Save"));     
    File.add(new MenuItem("Save As"));
    File.add(new MenuItem("Exit"));
    
 
    Edit.add(new MenuItem("Cut"));
    Edit.add(new MenuItem("Copy"));
    Edit.add(new MenuItem("Paste"));
          
    
    Operations.add(new MenuItem("Brightness"));
    Operations.add(new MenuItem("Contrast Stretching"));
    Operations.add(new MenuItem("Arithmetic"));
    Operations.add(new MenuItem("Blending"));
    Operations.add(new MenuItem("Histogram"));
    Operations.add(new MenuItem("Masking"));
    Operations.add(new MenuItem("Threshold"));
 
    setTitle("Image Analysis Tool");    
    setSize(900, 300);
    setVisible(true);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    String str = e.getActionCommand();    
    System.out.println("You selected " + str);
  }
  
  public static void main(String args[])
  {
    ImgA Iat = new ImgA();  
    
      Iat.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}    